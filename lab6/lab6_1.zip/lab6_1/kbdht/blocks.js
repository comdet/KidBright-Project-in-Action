Blockly.Blocks['dht_temperature'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("อ่านอุณหภูมิจาก DHT11 ขา")
        .appendField(new Blockly.FieldNumber(18, 0, 40), "pin");
    this.setOutput(true, "Number");
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['dht_humidity'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("อ่านความชื้นจาก DHT11 ขา")
        .appendField(new Blockly.FieldNumber(18, 0, 40), "pin");
    this.setOutput(true, "Number");
    this.setColour(230);
 this.setTooltip("");
 this.setHelpUrl("");
  }
};