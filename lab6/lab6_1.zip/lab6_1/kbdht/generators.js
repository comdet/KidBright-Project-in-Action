Blockly.JavaScript['dht_temperature'] = function(block) {
  var number_pin = block.getFieldValue('pin');
  var code = 'DEV_IO.KBDHT().readTemperature('+number_pin+')';
  return [code, Blockly.JavaScript.ORDER_NONE];
};

Blockly.JavaScript['dht_humidity'] = function(block) {
  var number_pin = block.getFieldValue('pin');
  var code = 'DEV_IO.KBDHT().readHumidity('+number_pin+')';
  return [code, Blockly.JavaScript.ORDER_NONE];
};
