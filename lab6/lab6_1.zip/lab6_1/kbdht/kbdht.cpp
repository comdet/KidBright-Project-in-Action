#include "esp_system.h"
#include "kidbright32.h"
#include "kbdht.h"
static const dht_sensor_type_t sensor_type = DHT_TYPE_DHT11;
KBDHT::KBDHT(void) {
	
}
float KBDHT::readTemperature(int pin){		
	int16_t temperature = 0;
    int16_t humidity = 0;
	if (dht_read_data(sensor_type,(gpio_num_t)pin, &humidity, &temperature) == ESP_OK)
        return temperature/10;
    return -1;
}
float KBDHT::readHumidity(int pin){	
	int16_t temperature = 0;
    int16_t humidity = 0;
	if (dht_read_data(sensor_type,(gpio_num_t)pin, &humidity, &temperature) == ESP_OK)
        return humidity/10;
    return -1;
}
